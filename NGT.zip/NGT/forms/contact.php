<?php
require_once 'config.php';

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Invalid request method.');
}

// Get and sanitize form data
$name    = trim($_POST['name'] ?? '');
$contact = trim($_POST['contact'] ?? '');
$email   = trim($_POST['email'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

// Basic server-side validation
if (empty($name) || empty($email) || empty($message) || empty($contact)) {
    die('Please fill in all required fields.');
}

if (strlen($name) < 3) {
    die('Name is too short.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('Invalid email address format.');
}

if (!preg_match("/^\+?[0-9 ]{7,20}$/", $contact)) {
    die('Please enter a valid contact number with country code.');
}

if (strlen($message) < 10) {
    die('Message must be at least 10 characters long.');
}

try {
    // Get database connection
    $conn = get_db_connection();

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO contact_submissions (name, contact, email, subject, message) VALUES (:name, :contact, :email, :subject, :message)");
    
    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':contact', $contact);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':subject', $subject);
    $stmt->bindParam(':message', $message);

    // Execute the statement
    if ($stmt->execute()) {
        // Send email notification to Admin
        $to = ADMIN_EMAIL;
        $email_subject = "New Contact Form Submission: $subject";
        $email_body = "You have received a new message from your website contact form.\n\n".
                     "Name: $name\n".
                     "Email: $email\n".
                     "Contact: $contact\n".
                     "Subject: $subject\n\n".
                     "Message:\n$message";
        
        $headers = "From: noreply@nexgenteck.com\r\n";
        $headers .= "Reply-To: $email\r\n";
        
        @mail($to, $email_subject, $email_body, $headers);
        
        echo "OK"; // Success response for AJAX
    } else {
        echo "Something went wrong. Please try again later.";
    }

} catch(PDOException $e) {
    // Log error and show a user-friendly message
    // error_log($e->getMessage());
    echo "Database Error: " . $e->getMessage();
}
?>

