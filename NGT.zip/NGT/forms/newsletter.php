<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Invalid request method.');
}

$email = trim($_POST['email'] ?? '');

if (empty($email)) {
    die('Email is required.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('Please enter a valid email address.');
}

try {
    $conn = get_db_connection();

    // Check if email already exists
    $check_stmt = $conn->prepare("SELECT id FROM newsletter_subscribers WHERE email = :email");
    $check_stmt->bindParam(':email', $email);
    $check_stmt->execute();

    if ($check_stmt->rowCount() > 0) {
        die('You are already subscribed!');
    }

    // Insert new subscriber
    $stmt = $conn->prepare("INSERT INTO newsletter_subscribers (email) VALUES (:email)");
    $stmt->bindParam(':email', $email);

    if ($stmt->execute()) {
        // Send email notification to Admin
        $to = ADMIN_EMAIL;
        $email_subject = "New Newsletter Subscriber";
        $email_body = "A new user has subscribed to your newsletter.\n\nEmail: $email";
        $headers = "From: noreply@nexgenteck.com\r\n";
        
        @mail($to, $email_subject, $email_body, $headers);

        echo "OK";
    } else {
        echo "Subscription failed. Please try again later.";
    }

} catch(PDOException $e) {
    if ($e->getCode() == 23000) { // Integrity constraint violation (duplicate entry)
        echo "You are already subscribed!";
    } else {
        echo "Database Error: " . $e->getMessage();
    }
}
?>
